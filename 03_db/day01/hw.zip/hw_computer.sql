-- CONNECTION: name=localhost 6
-- New script in localhost 6.
-- Connection Type: dev 
-- Url: jdbc:oracle:thin:@//localhost:1521/XE
-- workspace : H:\workspace\multi\03_db
-- Date: 2024. 5. 3.
-- Time: 오후 5:29:24

CREATE USER mouse IDENTIFIED BY 1111;
grant connect TO mouse;